﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AirlineReservationSystemBL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;


namespace AirlineReservationSystemPL
{
    /// <summary>
    /// Interaction logic for ViewTicket.xaml
    /// </summary>
    public partial class ViewTicket : Window
    {
        public ViewTicket()
        {
            InitializeComponent();
        }

        private void ArsCancel_Click(object sender, RoutedEventArgs e)
        {
            HomePage objHome = new HomePage();
            objHome.Show();
            this.Close();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            { 
            // for displaying ticket
            Reservation res = null;
            res = TicketBL.ViewTicketBL(txtTicketID.Text.ToString());
            IEnumerable<Reservation> resa = new List<Reservation> { res };
            dgViewTicket.ItemsSource = resa;

            }
            catch (AirlineException ae)
            {
                MessageBox.Show(ae.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
