﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirlineReservationSystemDAL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;

namespace AirlineReservationSystemBL
{
    public class FlightBL
    {
        private static bool IsInputValid(Flight flight)
        {
            StringBuilder sb = new StringBuilder();
            bool validFlight = true;

            //flight id length can be varied 

         
            if (flight.FlightID.ToString().Length < 5) 
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Flight Id Invalid");

            }
            if (flight.LaunchDate >= DateTime.Now)
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Launch Date Invalid");

            }
            //check krna h
            if (flight.Destination.Length<2)
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Destination Invalid");

            }
            //Check krna h
            if (flight.DeptTime.ToString() == " ")
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Departure time Invalid");

            }
            //Check krna h
            if (flight.ArrivalTime.ToString() == " ")
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Arrival time  Invalid");

            }
            if (flight.NoOfSeats < 0)
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "No of seats Invalid");

            }

            if (validFlight == false)
                throw new AirlineException(sb.ToString());

            return validFlight;
        }
        //BL Method to insert data in product table using Stored Procedure 
        public static bool InsertFlightBL(Flight flight)
        {
            bool isInserted = false;
            try
            {
                if (IsInputValid(flight))
                {
                    FlightDAL flightDAL = new FlightDAL();
                    isInserted = flightDAL.InsertFlightDAL(flight);

                }

            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception)
            {
                throw;
            }

            return isInserted;
        }
        public static bool DeleteFlightBL(int flightId)
        {
            bool isDeleted = false;
            try
            {
                if (flightId > 0)
                {
                    FlightDAL flightDAL = new FlightDAL();
                    isDeleted = flightDAL.DeleteFlightDAL(flightId);

                }

            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return isDeleted;
        }
        //BL Method to Select flights
        public static IEnumerable<Flight> SelectFlightsBL()
        {
            IEnumerable<Flight> flights = null;
            try
            {

                FlightDAL flightDAL = new FlightDAL();
               // flights = flightDAL.SelectFlightsDAL();

            }
        
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return flights;
        }
        public static Reservation ViewTicketBL(string ticketNo)
        {
            Reservation ticket = null;
            try
            {

                FlightDAL ticketDAL = new FlightDAL();
                 ticket = ticketDAL.ViewTicketDAL(ticketNo);

            }

            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ticket;
        }
        public static bool LoginUserBL(string userName, string password)
        {
            bool userFound = false;
            try
            {
                if (userName !=null && password != null)
                {
                    FlightDAL flightDAL = new FlightDAL();
                    userFound = flightDAL.LoginUserDAL(userName,password);

                }
            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return userFound;

        }
        public static string BookTicketBL(Reservation ticket)
        {
            string ticketNo = null;
            try
            {
                //if (userName != null && password != null)
                //{
                    FlightDAL flightDAL = new FlightDAL();
                    ticketNo = flightDAL.BookTicketDAL(ticket);

                //}
            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ticketNo;
        }

    }
}
