﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlineReservationSystemEntities
{
    public class Flight
    {
        public int FlightID { get; set; }
        public DateTime LaunchDate{ get; set; }
        public string Origin{ get; set; }
        public string Destination{ get; set; }
        public DateTime DeptTime { get; set; }
        public DateTime ArrivalTime { get; set; }
        public int NoOfSeats{ get; set; }
       // public decimal Fare { get; set; }

    }
}
