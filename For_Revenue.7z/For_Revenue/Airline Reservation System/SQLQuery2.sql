﻿select * from airline.Reservation

Select max(TicketNo) from airline.reservation
Select * from airline.reservation
Select fare from airline.FlightClass where Class='Business Class'