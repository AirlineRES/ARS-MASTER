﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;
using System.Data.SqlClient;
using System.Configuration;

namespace AirlineReservationSystemDAL
{
    public class RevenueOverallDAL
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public RevenueOverallDAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);

        }

        public IEnumerable<RevenueOverall> TotalRevenueSpecifiedDAL()
        {
            List<RevenueOverall> revList = new List<RevenueOverall>();
            try
            {
                cmd = new SqlCommand("[Airline].[USP_Rev123]", con);
                
                con.Open();

                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        RevenueOverall reven = new RevenueOverall();


                        reven.TotalSpecified = Convert.ToInt32(dr[0]);
                        //reven.Date2 = Convert.ToDateTime(dr[1]);
                        revList.Add(reven);

                    }
                }
                dr.Close();

            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return revList;
        }
    }
}
