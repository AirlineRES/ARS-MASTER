﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirlineReservationSystemEntities;
using System.Data.SqlClient;
using System.Configuration;



namespace AirlineReservationSystemDAL
{
    public class FlightRevenueDAL
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public FlightRevenueDAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);

        }
        public FlightRevenue TotalRevenueDAL(int FlightID)
        {
            FlightRevenue rev = new FlightRevenue();

            try
            {
                rev.flightID = FlightID;
                cmd = new SqlCommand("[airline].[USP_Rev]", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@f_Id", FlightID);

                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        //rev.flightID = Convert.ToInt32(dr[1]);
                        rev.TotalRevenue = Convert.ToInt32(dr[0]);
                        //rev.FareFirstClass = Convert.ToInt32(dr[1]);
                        //rev.FareEconomyClass = Convert.ToInt32(dr[2]);
                        //rev.NumberBusinessClass = Convert.ToInt32(dr[3]);
                        //rev.NumberFirstClass = Convert.ToInt32(dr[4]);
                        //rev.NumberEconomyClass = Convert.ToInt32(dr[5]);



                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return rev;
        }
    }
}
