﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirlineReservationSystemEntities;
using AirlineReservationSystemDAL;
using AirlineReservationSystemExceptions;

namespace AirlineReservationSystemBL
{
    public class FlightRevenueBL
    {
        public static FlightRevenue TotalRevenueBL(int fid)
        {
            FlightRevenue rev = null;
            try
            {
                FlightRevenueDAL revDAL = new FlightRevenueDAL();
                rev = revDAL.TotalRevenueDAL(fid);
                // rev = revDAL.SelectAllDAL(fid);
            }
            catch (AirlineException ex)
            {
                throw ex;
            }


            return rev;

        }
    }
}
