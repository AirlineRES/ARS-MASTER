﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;
using AirlineReservationSystemDAL;

namespace AirlineReservationSystemBL
{
    class RevenueOverallBL
    {
        public static IEnumerable<RevenueOverall> TotalRevenueSpecifiedBL()
        {
            IEnumerable<RevenueOverall> rev = null;
            try
            {
                RevenueOverallDAL revDAL = new RevenueOverallDAL();


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return rev;
        }
    }
}
