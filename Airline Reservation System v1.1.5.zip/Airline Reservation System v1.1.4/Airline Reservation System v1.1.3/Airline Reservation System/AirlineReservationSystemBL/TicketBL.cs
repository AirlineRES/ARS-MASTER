﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirlineReservationSystemDAL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;

namespace AirlineReservationSystemBL
{
    public class TicketBL
    {
        public static Reservation ViewTicketBL(string ticketNo)
        {
            Reservation ticket = null;
            try
            {

                TicketDAL ticketDAL = new TicketDAL();
                ticket = ticketDAL.ViewTicketDAL(ticketNo);

            }

            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ticket;
        }
        public static bool LoginUserBL(string userName, string password)
        {
            bool userFound = false;
            try
            {
                if (userName != null && password != null)
                {
                    TicketDAL ticketDAL = new TicketDAL();
                    userFound = ticketDAL.LoginUserDAL(userName, password);

                }
            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return userFound;

        }
        public static string BookTicketBL(Reservation ticket)
        {
            string ticketNo = null;
            try
            {
                //if (userName != null && password != null)
                //{
                FlightDAL flightDAL = new FlightDAL();
                ticketNo = flightDAL.BookTicketDAL(ticket);

                //}
            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ticketNo;
        }
    }
}
