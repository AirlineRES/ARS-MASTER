using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirlineReservationSystemBL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;

namespace AirlineReservationSystemConsolePL
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                //PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddFlight();
                        break;
                    case 2:
                        DeleteFlight();
                        return;
                    case 3:
                        BookTicket();
                        //{
                        //    int ticketNumber = 500;
                        //    string ticketNo = "CG" + (10000000 + ticketNumber);
                        //    Console.WriteLine(ticketNo);
                        //}
                           //Login();
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }
        private static void AddFlight()
        {
            try
            {  

                Flight newFlight = new Flight();
                Console.WriteLine("Enter Flight ID");
                newFlight.FlightID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter LaunchDate");
                newFlight.LaunchDate = Convert.ToDateTime(Console.ReadLine());              
                Console.WriteLine("Enter Origin");
                newFlight.Origin = Console.ReadLine();
                Console.WriteLine("Enter Destination");
                newFlight.Destination = Console.ReadLine();
                Console.WriteLine("Enter DeptTime");
                newFlight.DeptTime = Console.ReadLine();
                Console.WriteLine("Enter ArrivalTime");
                newFlight.ArrivalTime = Console.ReadLine();
                Console.WriteLine("Enter NoOfSeats");
                newFlight.NoOfSeats = Convert.ToInt32(Console.ReadLine());
                //Console.WriteLine("Enter Fare");
                //newFlight.Fare = Convert.ToInt32(Console.ReadLine());
                bool flightAdded = FlightBL.InsertFlightBL(newFlight);

                if (flightAdded)
                    Console.WriteLine("Flight Added");
                else
                    Console.WriteLine("Flight not Added");
            }
            catch (AirlineException ae)
            {
                Console.WriteLine(ae.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void DeleteFlight()
        {
            try
            {

                int flightId;
                Console.WriteLine("Enter Flight ID");
                flightId = Convert.ToInt32(Console.ReadLine());
               
                bool flightDeleted = FlightBL.DeleteFlightBL(flightId);

                if (flightDeleted)
                    Console.WriteLine("Flight Deleted");
                else
                    Console.WriteLine("Flight not Deleted");
            }
            catch (AirlineException ae)
            {
                Console.WriteLine(ae.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void Login()
        {
            bool loggedIn = false;
            string username, password;
            Console.WriteLine("Enter user name");
            username = Console.ReadLine();
            Console.WriteLine(" Enter Password");
            password = Console.ReadLine();

            loggedIn = TicketBL.LoginUserBL(username, password);
            if (loggedIn)
            {
                Console.WriteLine("User Logged in");
            }
            Console.ReadKey();
        }
        private static void BookTicket()
        {
            try
            {

                Reservation ticket = new Reservation();

                ticket.FlightId = "101";
                ticket.DateofBooking = DateTime.Now;
                ticket.JourneyDate = DateTime.Now;
                ticket.PassengerName = "Amit";
                ticket.ContactNo = "9981880044";
                ticket.Email = "amitpotdar50@gmail.com";
                ticket.NoofTickets = 5;
                ticket.Age = 22;
                ticket.Class = "Business Class";
                ticket.Gender = "Male";


                
               string ticketNo = TicketBL.BookTicketBL(ticket);
                Console.WriteLine(ticketNo);
                //Console.WriteLine("Enter Flight ID");
                //newFlight.FlightID = Convert.ToInt32(Console.ReadLine());
                //Console.WriteLine("Enter LaunchDate");
                //newFlight.LaunchDate = Convert.ToDateTime(Console.ReadLine());
                //Console.WriteLine("Enter Origin");
                //newFlight.Origin = Console.ReadLine();
                //Console.WriteLine("Enter Destination");
                //newFlight.Destination = Console.ReadLine();
                //Console.WriteLine("Enter DeptTime");
                //newFlight.DeptTime = Convert.ToDateTime(Console.ReadLine());
                //Console.WriteLine("Enter ArrivalTime");
                //newFlight.ArrivalTime = Convert.ToDateTime(Console.ReadLine());
                //Console.WriteLine("Enter NoOfSeats");
                //newFlight.NoOfSeats = Convert.ToInt32(Console.ReadLine());
                ////Console.WriteLine("Enter Fare");
                ////newFlight.Fare = Convert.ToInt32(Console.ReadLine());
                //bool flightAdded = FlightBL.InsertFlightBL(newFlight);

                //if (flightAdded)
                //    Console.WriteLine("Flight Added");
                //else
                //    Console.WriteLine("Flight not Added");
            }
            catch (AirlineException ae)
            {
                Console.WriteLine(ae.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
