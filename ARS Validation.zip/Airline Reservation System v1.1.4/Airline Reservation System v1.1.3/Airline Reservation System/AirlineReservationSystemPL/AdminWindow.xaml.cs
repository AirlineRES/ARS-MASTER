﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AirlineReservationSystemBL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;


namespace AirlineReservationSystemPL
{
    /// <summary>
    /// Interaction logic for AdminWindow.xaml
    /// </summary>
    public partial class AdminWindow : Window
    {
        public AdminWindow()
        {
            InitializeComponent();
        }

        public bool ValidRevenue()
        {
            StringBuilder sbrev = new StringBuilder();
            bool isValidRev = true;

            if (txtGenID.Text.Length == 0)
            {
                MessageBox.Show("Please Enter Flight Id...!!!");
                isValidRev = false;
            }

            if (!isValidRev)
            {
                throw new Exception(sbrev.ToString());
            }

            return isValidRev;
        }

        public bool ValidRemove()
        {
            StringBuilder sb = new StringBuilder();
            bool isValidRem = true;

            if (txtRemID.Text.Length == 0)
            {
                MessageBox.Show("Please Enter Flight Id...!!!");
                isValidRem = false;
            }

            if (!isValidRem)
            {
                throw new Exception(sb.ToString());
            }

            return isValidRem;
        }

        private void AddFlight_Click(object sender, RoutedEventArgs e)
        {
            try
            { 
                AddFlight addFlight = new AddFlight();
                addFlight.Show();
                this.Close();
            }
            catch (AirlineException ae)
            {
                MessageBox.Show(ae.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnGenRev_Click(object sender, RoutedEventArgs e)
        {
            if (ValidRevenue())
            {
                //revenue generate
            }
        }

        private void BtnRemFlight_Click(object sender, RoutedEventArgs e)
        {
            if (ValidRemove())
            {
                //remove flight
            }
        }
    }
}
