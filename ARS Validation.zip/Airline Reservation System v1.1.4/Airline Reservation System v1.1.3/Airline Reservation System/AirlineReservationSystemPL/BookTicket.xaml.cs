﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AirlineReservationSystemBL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;


namespace AirlineReservationSystemPL
{
    /// <summary>
    /// Interaction logic for BookTicket.xaml
    /// </summary>
    public partial class BookTicket : Window
    {
        public BookTicket()
        {
            InitializeComponent();
        }

        public bool Validation()
        {
            StringBuilder sb = new StringBuilder();
            bool isValid = true;

            if (txtBookName.Text.Length == 0)
            {
                sb.Append("Please Enter Name...!!!");
                isValid = false;
            }

            if (txtBookContact.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Contact...!!!");
                isValid = false;
            }

            if (txtBookemail.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Email...!!!");
                isValid = false;
            }

            if (rbBookMale.IsChecked ==false || rbBookFemale.IsChecked==false)
            {
                sb.Append("\nPlease Enter Gender...!!!");
                isValid = false;
            }

            if (txtBookPassengers.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Number of Passengers...!!!");
                isValid = false;
            }
            if (cbFirstClass.IsChecked == false || cbBusinessClass.IsChecked == false || cbEconomyClass.IsChecked == false)
            {
                sb.Append("\nPlease Enter Classes...!!!");
                isValid = false;
            }

            if (!isValid)
            {
                throw new Exception(sb.ToString());
            }

            return isValid;
        }

        private void BtnBook_Click(object sender, RoutedEventArgs e)
        { 
         try
            {
                if (Validation())
                {
                    RadioButton ds = new RadioButton();
                    //string rd = class
                    Reservation ticket = new Reservation();

                    //ticket.FlightId = "";
                    //        ticket.DateofBooking = DateTime.Now.Date;
                    //        ticket.JourneyDate = DateTime.Now.Date; // Journery Date not Specified
                    //        ticket.PassengerName = txtBookName.Text;
                    //        ticket.ContactNo = txtBookContact.Text;
                    //        ticket.Email = txtBookemail.Text;
                    //        ticket.NoofTickets = Convert.ToInt32(txtBookPassengers.Text);
                    //        ticket.Age = ""; // Age no specified
                    //        ticket.Class = ;
                    //        ticket.Gender = "Male";



                    string ticketNo = TicketBL.BookTicketBL(ticket);
                    MessageBox.Show(ticketNo);
                }
              
            }
            catch (AirlineException ae)
            {
                MessageBox.Show(ae.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
