﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AirlineReservationSystemBL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;


namespace AirlineReservationSystemPL
{
    /// <summary>
    /// Interaction logic for HomePage.xaml
    /// </summary>
    public partial class HomePage : Window
    {
        public HomePage()
        {
            InitializeComponent();
        }

        public bool Validation()
        {
            StringBuilder sb = new StringBuilder();
            bool isValid = true;

            if (dpTravelDate.Text.Length == 0)
            {
                sb.Append("Please Enter Travel Date...!!!");
                isValid = false;
            }

            if (dpReturnDate.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Return Date...!!!");
                isValid = false;
            }

            if (txtSource.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Source...!!!");
                isValid = false;
            }

            if (txtDestination.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Destination...!!!");
                isValid = false;
            }
            if (!isValid)
            {
                throw new Exception(sb.ToString());
            }

            return isValid;
        }

        private void btnViewTicket_Click(object sender, RoutedEventArgs e)
        {
            ViewTicket viewTicket = new ViewTicket();
            viewTicket.Show();
        }

        private void btnAboutUs_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnContactUs_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Validation())
                {

                    IEnumerable<Flight> flights = FlightBL.ViewFlightsBL(txtSource.Text, txtDestination.Text);
                    dgFlight.ItemsSource = flights;
                    dgFlight.Visibility = Visibility.Visible;
                }
             }
            catch (AirlineException ae)
            {
                MessageBox.Show(ae.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAdminLogin_Click(object sender, RoutedEventArgs e)
        {
            AdminLogin adminLogin = new AdminLogin();
            adminLogin.Show();
            this.Close();
        }
    }
}
