﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;
using System.Data.SqlClient;
using System.Configuration;

namespace AirlineReservationSystemDAL
{
    public class FlightDAL
    {
        //Declaring SqlConnection object reference
        SqlConnection con = null;

        //Declaring SqlCommand object reference
        SqlCommand cmd = null;

        //Declaring Data Reader object reference
        SqlDataReader dr = null;
        
        public FlightDAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        }

        //DAL Method to insert data in Flights table using Stored Procedure 

        public bool InsertFlightDAL(Flight flight)
        {
            bool isInserted = false;
            try
            {
                cmd = new SqlCommand("Airline.USP_FLIGHTINSERT", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flightId", flight.FlightID);
                cmd.Parameters.AddWithValue("@launchDate", flight.LaunchDate);
                cmd.Parameters.AddWithValue("@origin", flight.Origin);
                cmd.Parameters.AddWithValue("@destination", flight.Destination);
                cmd.Parameters.AddWithValue("@deptTime", flight.DeptTime);
                cmd.Parameters.AddWithValue("@arrivalTime", flight.ArrivalTime);
                cmd.Parameters.AddWithValue("@noOfSeats", flight.NoOfSeats);
                //cmd.Parameters.AddWithValue("@fare", flight.Fare);
               
                con.Open();
                cmd.ExecuteNonQuery();
                isInserted = true;
            }

            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return isInserted;
        }

        public bool DeleteFlightDAL(int id)
        {
            bool isDeleted = false;
            try
            {
                cmd = new SqlCommand("[Airline].[USP_FLIGHTDELETE]", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flightId", id);
                con.Open();
                cmd.ExecuteNonQuery();
                isDeleted = true;
            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }

            return isDeleted;
        }
        
        //DAL Method to Select and populate data from Flights table

        public IEnumerable<Flight> ViewFlightsDAL(string origin,string destination)
        {
            List<Flight> flights = new List<Flight>();
            try
            {
                cmd = new SqlCommand("Airline.USP_VIEWFLIGHTS", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@origin", origin);
                cmd.Parameters.AddWithValue("@destination", destination);
                con.Open();
                
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Flight flight = new Flight();
                        flight.FlightID = Convert.ToInt32(dr[0]);
                        //flight.LaunchDate = Convert.ToDateTime(dr[1]);
                        flight.Origin = dr[1].ToString();
                        flight.Destination = dr[2].ToString();
                        flight.DeptTime =dr[3].ToString();
                        flight.ArrivalTime = dr[4].ToString();
                        flight.NoOfSeats =Convert.ToInt32(dr[5]);
                        flights.Add(flight);
                    }
                }
                dr.Close();

            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return flights;
        }
                
        //DAL Method to Select ticket from reservation table

        public Reservation ViewTicketDAL(string ticketNo)
        {
            Reservation ticket = new Reservation();
            try
            {
                cmd = new SqlCommand("airline.USP_VIEWRESERVATION", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ticketNo", ticketNo);
                con.Open();
                
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                                         
                        ticket.TicketNo = dr[1].ToString();
                        ticket.FlightId = dr[2].ToString();
                        ticket.DateofBooking= Convert.ToDateTime(dr[3]);
                        ticket.JourneyDate = Convert.ToDateTime(dr[4]);
                        ticket.PassengerName = dr[5].ToString();
                        ticket.Age = Convert.ToInt32(dr[6]);
                        ticket.Gender = dr[7].ToString();
                        ticket.ContactNo = dr[8].ToString();
                        ticket.Email = dr[9].ToString();
                        ticket.Class = dr[10].ToString();
                        ticket.NoofTickets = Convert.ToInt32(dr[11]);
                        ticket.TotalFare = Convert.ToDecimal(dr[12]);
                        ticket.Status = dr[13].ToString();
                    }
                }
                dr.Close();

            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return ticket;
        }

        //This is method to book ticket (not completed)
        public string BookTicketDAL(Reservation ticket)
        {
            string ticketNo = null;
            try
            {
                decimal fare = getFare(ticket.Class);
                decimal totalFare = fare * ticket.NoofTickets;
                cmd = new SqlCommand("airline.USP_RESERVATIONINSERT", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flightID ", ticket.FlightId);
                cmd.Parameters.AddWithValue("@dateofBooking ", ticket.DateofBooking);
                cmd.Parameters.AddWithValue("@journeyDate ", ticket.JourneyDate);
                cmd.Parameters.AddWithValue("@passengerName ", ticket.PassengerName);
                cmd.Parameters.AddWithValue("@age ", ticket.Age);
                cmd.Parameters.AddWithValue("@gender ", ticket.Gender);
                cmd.Parameters.AddWithValue("@contacNo ", ticket.ContactNo);
                cmd.Parameters.AddWithValue("@email ", ticket.Email);
                cmd.Parameters.AddWithValue("@class ", ticket.Class);
                cmd.Parameters.AddWithValue("@totalFare ", totalFare);
                cmd.Parameters.AddWithValue("@noofTickets", ticket.NoofTickets);
                cmd.Parameters.AddWithValue("@reservationStatus","Booked");
                con.Open();               
                                                                                                            
                cmd.ExecuteNonQuery();
                con.Close();

                ticketNo = getTicketNo();
                                
            }

            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return ticketNo; 
          
        }
        ////
  
        public decimal getFare(string flightClass)
        {
            cmd = new SqlCommand("Select fare from airline.FlightClass where Class=@flightClass", con);
            cmd.Parameters.AddWithValue("@flightClass", flightClass);
            con.Open();
            decimal fare =  Convert.ToDecimal( cmd.ExecuteScalar());
            con.Close();
            return fare;
          //  Console.WriteLine(fare);
        }

        //getFare
        //insert to table
        //print ticket id

        public string getTicketNo()
        {
            

            cmd = new SqlCommand("Select max(TicketNo) from airline.reservation", con);
            con.Open();
            string ticketNo = cmd.ExecuteScalar().ToString();
            //string ticketNo = "CG" + (10000000 + ticketNumber);
            con.Close();
            return ticketNo;
        }

 
    }
}
